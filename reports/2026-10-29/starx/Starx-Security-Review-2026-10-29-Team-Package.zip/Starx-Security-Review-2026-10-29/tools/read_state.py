"""Read public X Layer state. Contains no signing or transaction submission."""
import concurrent.futures
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parent
RPC = 'https://rpc.xlayer.tech'
LAUNCHPAD = '0x37a3889888999c126D9E3e70ab8037fe486C9551'
DELEGATE = '0xe40ccb2d94975c51bff0c004efdfd9b3a5796fa4'
MASK = (1 << 64) - 1
ROT = [[0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]]
RC = [0x1,0x8082,0x800000000000808a,0x8000000080008000,0x808b,0x80000001,0x8000000080008081,0x8000000000008009,0x8a,0x88,0x80008009,0x8000000a,0x8000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x80000001,0x8000000080008008]

def rol(v,n):
    return ((v << n) | (v >> ((64-n) % 64))) & MASK

def keccak(data):
    rate = 136
    buf = bytearray(data)
    buf.append(1)
    buf.extend(b'\0' * ((rate-len(buf)%rate)%rate))
    buf[-1] |= 128
    a = [0] * 25
    for offset in range(0,len(buf),rate):
        for i in range(rate//8):
            a[i] ^= int.from_bytes(buf[offset+i*8:offset+i*8+8], 'little')
        for rc in RC:
            c = [a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20] for x in range(5)]
            d = [c[(x-1)%5]^rol(c[(x+1)%5],1) for x in range(5)]
            for x in range(5):
                for y in range(5): a[x+5*y] ^= d[x]
            b = [0]*25
            for x in range(5):
                for y in range(5): b[y+5*((2*x+3*y)%5)] = rol(a[x+5*y], ROT[x][y])
            for x in range(5):
                for y in range(5): a[x+5*y] = b[x+5*y]^((~b[(x+1)%5+5*y])&b[(x+2)%5+5*y])
            a[0] ^= rc
    return b''.join(v.to_bytes(8,'little') for v in a)[:32]

def rpc(method,params):
    assert method in {'eth_blockNumber','eth_getBlockByNumber','eth_getCode','eth_getStorageAt','eth_call','eth_getLogs','eth_getTransactionByHash','eth_getTransactionReceipt'}
    req = urllib.request.Request(RPC, data=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as res: return json.load(res)

def call_data(signature,args=''):
    return '0x'+keccak(signature.encode()).hex()[:8]+args

def main():
    assert keccak(b'').hex() == 'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470'
    assert call_data('transfer(address,uint256)') == '0xa9059cbb'
    block = rpc('eth_blockNumber',[])['result']
    results = {'block':block,'blockNumber':int(block,16),'launchpad':LAUNCHPAD}
    block_info = rpc('eth_getBlockByNumber',[block,False])
    results['blockHeader'] = {k:block_info.get('result',{}).get(k) for k in ['hash','timestamp','baseFeePerGas']}
    impl = rpc('eth_getStorageAt',[LAUNCHPAD,'0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc',block])
    results['implementation'] = '0x'+impl['result'][-40:]
    jobs = [(sig, 'eth_call', [{'to':LAUNCHPAD,'data':call_data(sig)},block]) for sig in ['gaslessRequired()','upgradesFrozen()','owner()','pendingOwner()','hook()','paused()','createOpen()','tokenCount()','walletCapEnabled()','createFee()','snipeStartBps()','snipeWindow()']]
    jobs += [('implCode','eth_getCode',[results['implementation'],block])]
    dh = keccak(bytes.fromhex('ef0100'+DELEGATE[2:])).hex()
    jobs += [('allowedDelegate','eth_call',[{'to':LAUNCHPAD,'data':call_data('allowedCodehash(bytes32)',dh)},block])]
    jobs += [('plainEOAIsAgent','eth_call',[{'to':LAUNCHPAD,'data':call_data('isAgentWallet(address)','1'.rjust(64,'0'))},block])]
    def run(job):
        label,method,params=job
        try: return label,rpc(method,params)
        except Exception as e: return label,{'error':str(e)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        for label,result in ex.map(run,jobs):
            results[label]=result
            if label=='implCode': print(label,'bytes',len(result.get('result',''))//2-1)
            else: print(label,json.dumps(result))
    (ROOT/'state-snapshot.json').write_text(json.dumps(results,indent=2))
    print('block',int(block,16),'implementation',results['implementation'])

if __name__ == '__main__': main()
