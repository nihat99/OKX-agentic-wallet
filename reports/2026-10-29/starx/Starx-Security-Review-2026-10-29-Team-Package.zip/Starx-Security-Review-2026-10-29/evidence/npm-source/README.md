# starx CLI

Agent CLI for [starx](https://starx.meme), the agent-only token launchpad on X Layer (chainId 196).

starx never holds keys and has no private-key, RPC-signer or ordinary-wallet mode. It builds each call from the starx contract ABIs, simulates it against X Layer, and hands it to the **OKX Onchain OS Agentic Wallet** (`onchainos wallet contract-call`) to sign and send. X Layer gas is sponsored, so trades cost no gas.

## Setup

The npm package is **`starx-meme`**; the command it installs is `starx`. (The npm package named `starx` belongs to an unrelated project, so never run `npx starx`.)

```bash
npx -y @okxweb3/onchainos-installer install
onchainos wallet login
npx -y starx-meme install
npx -y starx-meme activate
```

Or install it once and use the `starx` command:

```bash
npm i -g starx-meme
starx install
starx activate
```

`starx install` checks that onchainos is installed and signed in, shows your Agentic Wallet address on X Layer, and checks whether it is delegated to the OKX SmartWallet that starx allows.

**A new wallet needs one activation first.** An Onchain OS wallet is delegated to the OKX SmartWallet (EIP-7702) by its first X Layer transaction. OKX simulates every call before sending it, and that simulation runs without the delegation, so a starx call cannot be a wallet's very first X Layer transaction. `starx activate` makes that first transaction: it sends 0.0001 OKB from the wallet to itself (no gas, and the OKB stays in the wallet), then confirms the delegation. Deposit a little OKB on X Layer before running it. `starx install` reports `NOT_ACTIVATED` until this is done, and `launch` / `buy` / `sell` point to it as well. A wallet that is already active is left alone. Without a global install, run any command as `npx -y starx-meme <command>`.

## Commands

| Command | What it does |
|---|---|
| `starx install` | onchainos, sign-in, wallet address, delegation check |
| `starx activate` | once per new wallet: sends 0.0001 OKB to itself (no gas, the OKB stays) so X Layer delegates it to the OKX SmartWallet |
| `starx launch --name <N> --symbol <S> --logo <url> --description <text> [--website <url>] [--twitter @x] [--telegram @group] [--link <url>] [--quote OKB] [--in <amount>]` | create a token; `--in` makes the first buy, which never pays an anti-snipe fee |
| `starx buy <token> --in <amount> [--slippage 1] [--accept-snipe-fee]` | buy on the bonding curve |
| `starx sell <token> --amount <n\|all> [--slippage 1]` | sell back to the curve |
| `starx status <token>` | curve progress, price, market cap, anti-snipe fee now; for graduated tokens the V4 pool and its price |
| `starx list [--limit 20]` | newest tokens first |
| `starx swap <token> --in <amount> \| --sell <n\|all> [--slippage 1]` | trade a graduated token in its Uniswap V4 pool |
| `starx claim [--hook <address>]` | collect your creator share of the fees from your graduated tokens' pools |
| `starx confirm` | send the call the wallet asked you to confirm |

Add `--json` to any command for machine-readable output.

| Exit code | Meaning |
|---|---|
| `0` | done (`success: true`) |
| `1` | failed: bad input, a simulation or transaction revert, or a call that reverted inside the OKX smart wallet |
| `2` | the wallet needs confirmation (`confirming: true`): see below |
| `3` | sent but not seen on X Layer before `STARX_RECEIPT_TIMEOUT_MS` (`pending: true`): check `explorer` before sending again |

- Quotes: starx launches with OKB as the only quote. When starx enables another quote (for example USDT0), `--quote USDT0` or `--quote <token address>` works without a new CLI version; until then the CLI says the quote is not enabled.
- Amounts: `--in` is in the token's quote; `--amount` and `--sell` are in tokens. An amount with more decimals than the quote or token has, or one that is 0 in its smallest unit, is refused.
- Smart wallet calls: Onchain OS sends each call as an ERC-4337 UserOperation, so the transaction can land while the call inside it reverts. starx reads the EntryPoint's `UserOperationEvent` for your wallet and reports such a call as failed, with the starx error (for example `Slippage`) when the wallet passes it on.
- Links: `--twitter` takes `@handle` or an x.com / twitter.com profile URL (query strings such as `?s=21` are fine); `--telegram` takes `@group`, `t.me/group`, `t.me/+invite` or `t.me/joinchat/invite` URLs. Both are stored as https URLs.
- Fees: every trade pays 1%. At launch half of it goes to the token's creator and half to the platform; starx can change the split later.
- Creator fees: on the curve your share arrives with each trade. After graduation it collects in the pool's hook; `starx status <token>` shows `creatorFeesUnclaimed` and `starx claim` sends it to your wallet, from every hook your tokens use (the launchpad's current hook and the hook stored on each token you created; `--hook` checks only that one). OKB fees arrive as WOKB (wrapped OKB, 1:1).
- Wallet cap: one wallet can hold at most 1% of a token while it is on the curve. If a buy would go over, it is cut to the cap and the rest is refunded. When starx turns the cap off, `starx status` shows `roomUnderCap: no cap`.
- Anti-snipe fee: off at launch. If starx turns it on, tokens created afterwards charge buys an extra fee that decays to zero over the window starx set. `starx status` shows it, and `starx buy` refuses to pay it unless you pass `--accept-snipe-fee`.
- ERC-20 quote approvals: for a quote like USDT0, `buy`, `launch` and `swap` approve the launchpad or router themselves when needed, wait for the approval to land, then continue.
- Graduated pools: the Uniswap V4 pool is open to any wallet, and `starx swap` works with any Onchain OS wallet.

## Confirmation

When the Onchain OS wallet answers that a call needs confirmation (exit code 2):

1. starx keeps that exact call and prints the wallet's message. It never adds `--force` on the first try.
2. After the wallet owner agrees, `starx confirm` re-simulates the same call and sends it with `--force`.

A kept call expires after 15 minutes and only works for the wallet it was prepared for.

## Environment

| Variable | Use |
|---|---|
| `STARX_RPC_URL` | X Layer RPC for reads and simulations (default `https://rpc.xlayer.tech`) |
| `STARX_DEPLOYMENT` | a deployment JSON (`launchpad`, `router`, `hook`, `collector`, optional `rpcUrl` and `deployBlock`), e.g. a local fork's `deploy/local-seed.json` |
| `STARX_ONCHAINOS` | path to the onchainos binary (a `.js` file runs under node; used by the tests) |
| `STARX_RECEIPT_TIMEOUT_MS` | how long to wait for a sent transaction to land before reporting it as pending (default 300000) |
| `STARX_HOME` | where the call waiting for confirmation is kept (default `~/.starx`) |

## Development

```bash
npm install
npm test
npm run sync-abi
```

`npm run sync-abi` copies `../contracts/abi` into `abi/`; a unit test fails if they drift.

End to end, against a local X Layer fork seeded by `xlayer/contracts/script/fork.ps1`:

```bash
anvil --fork-url https://rpc.xlayer.tech --port 8547 --hardfork prague --block-base-fee-per-gas 0 --gas-price 0
powershell -NoProfile -ExecutionPolicy Bypass -File ../contracts/script/fork.ps1
STARX_E2E=1 STARX_DEPLOYMENT=../contracts/deploy/local-seed.json npm run test:e2e
```

The end-to-end run uses `fixtures/fork-onchainos.js`, which stands in for onchainos: it sends each call with `cast send --unlocked --gas-price 0` from the Onchain OS wallet that the fork impersonates.
